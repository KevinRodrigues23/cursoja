package br.com.cursoja.controlecursoja.model.dao;

/*import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import br.com.cursoja.controlecursoja.model.entidade.Turma;
import br.com.cursoja.controlecursoja.model.entidade.Professor;
import br.com.cursoja.controlecursoja.model.entidade.Curso;*/

public class TurmaDao extends Conexao{
	
}
